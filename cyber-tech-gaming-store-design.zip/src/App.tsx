import Navbar from './components/Navbar';
import Hero from './components/Hero';
import RankSection from './components/RankCard';
import StoreSection from './components/StoreSection';
import TopDonors from './components/TopDonors';
import Features from './components/Features';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#050508] text-white overflow-x-hidden">
      <Navbar />
      <Hero />
      <RankSection />
      <StoreSection />
      <TopDonors />
      <Features />
      <Footer />
    </div>
  );
}
