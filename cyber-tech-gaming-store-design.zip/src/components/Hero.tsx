import { motion } from 'framer-motion';
import { Zap, Shield, ArrowDown, Play } from 'lucide-react';

const stats = [
  { value: '50K+', label: 'Players', color: 'text-purple-400' },
  { value: '99.9%', label: 'Uptime', color: 'text-cyan-400' },
  { value: '1.2M+', label: 'Purchases', color: 'text-pink-400' },
  { value: '4.9★', label: 'Rating', color: 'text-yellow-400' },
];

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url(/images/hero-bg.jpg)' }}
      />

      {/* Overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050508]/80 via-[#050508]/50 to-[#050508]" />
      <div className="absolute inset-0 cyber-grid opacity-60" />
      <div className="absolute inset-0 hex-pattern opacity-40" />

      {/* Animated particles */}
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className="particle"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: `${Math.random() * 4 + 1}px`,
            height: `${Math.random() * 4 + 1}px`,
            background: i % 2 === 0 ? '#a855f7' : '#06b6d4',
            animationDelay: `${Math.random() * 4}s`,
            animationDuration: `${Math.random() * 3 + 3}s`,
            opacity: Math.random() * 0.7 + 0.3,
          }}
        />
      ))}

      {/* Glowing orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-600/15 rounded-full blur-[100px] pointer-events-none" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-16">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-purple-500/40 mb-8"
        >
          <Zap className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
          <span className="text-xs font-['Rajdhani'] font-semibold tracking-[0.25em] text-gray-300 uppercase">
            Season 7 — New Ranks Available
          </span>
          <span className="px-2 py-0.5 bg-purple-500/30 rounded-full text-purple-300 text-[10px] font-bold tracking-wider">NEW</span>
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="mb-6"
        >
          <h1 className="font-['Orbitron'] font-black text-5xl sm:text-7xl lg:text-8xl leading-none tracking-tight">
            <span className="block text-white glitch-text">CYBER</span>
            <span className="block shimmer-text">CRAFT</span>
            <span className="block text-white/80 text-3xl sm:text-4xl lg:text-5xl mt-2 font-['Rajdhani'] font-light tracking-[0.3em]">
              NETWORK
            </span>
          </h1>
        </motion.div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.25 }}
          className="text-gray-400 text-lg sm:text-xl max-w-2xl mx-auto mb-10 font-['Rajdhani'] leading-relaxed"
        >
          The most advanced Minecraft gaming network. Unlock exclusive ranks, cosmetics, and powers.
          <span className="text-cyan-400"> Dominate the server.</span>
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
        >
          <motion.a
            href="#ranks"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            className="group relative flex items-center gap-3 px-8 py-4 rounded-xl font-['Orbitron'] font-bold text-sm tracking-widest text-white overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-purple-700 rounded-xl" />
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <div className="absolute inset-0 rounded-xl shadow-lg shadow-purple-500/40 group-hover:shadow-purple-500/70 transition-shadow duration-300" />
            <Shield className="relative w-5 h-5" />
            <span className="relative">BROWSE RANKS</span>
          </motion.a>

          <motion.a
            href="#store"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            className="group flex items-center gap-3 px-8 py-4 rounded-xl font-['Orbitron'] font-bold text-sm tracking-widest neon-btn-cyan"
          >
            <Play className="w-4 h-4" />
            <span>VISIT STORE</span>
          </motion.a>
        </motion.div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.55 }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto mb-16"
        >
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 + i * 0.1 }}
              className="glass rounded-xl p-4 border border-white/5 hover:border-purple-500/30 transition-all duration-300 group"
            >
              <div className={`font-['Orbitron'] font-black text-2xl sm:text-3xl ${stat.color} group-hover:scale-110 transition-transform duration-300 inline-block`}>
                {stat.value}
              </div>
              <div className="text-gray-400 text-xs font-['Rajdhani'] tracking-widest mt-1 uppercase">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="flex flex-col items-center gap-2"
        >
          <span className="text-xs text-gray-500 font-['Rajdhani'] tracking-[0.3em] uppercase">Scroll to Explore</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            <ArrowDown className="w-5 h-5 text-purple-400" />
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#050508] to-transparent pointer-events-none" />
    </section>
  );
}
