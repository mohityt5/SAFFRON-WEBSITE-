import { motion } from 'framer-motion';
import { Shield, Zap, Globe, Lock, Clock, Headphones, Award, RefreshCw } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Secure Payments',
    desc: 'Bank-level encryption & multiple payment methods supported.',
    color: '#a855f7',
    delay: 0,
  },
  {
    icon: Zap,
    title: 'Instant Delivery',
    desc: 'Perks are applied to your account within seconds of purchase.',
    color: '#06b6d4',
    delay: 0.1,
  },
  {
    icon: Globe,
    title: 'Global Servers',
    desc: 'Low-latency servers across North America, Europe & Asia.',
    color: '#10b981',
    delay: 0.2,
  },
  {
    icon: Lock,
    title: 'Permanent Perks',
    desc: 'All rank perks are permanent and never expire. Buy once, keep forever.',
    color: '#f59e0b',
    delay: 0.3,
  },
  {
    icon: Clock,
    title: '24/7 Availability',
    desc: '99.9% uptime guaranteed. We never sleep, so you can play anytime.',
    color: '#ec4899',
    delay: 0.4,
  },
  {
    icon: Headphones,
    title: 'Priority Support',
    desc: 'Dedicated support team ready to help you with any issues.',
    color: '#8b5cf6',
    delay: 0.5,
  },
  {
    icon: Award,
    title: 'Season Rewards',
    desc: 'Exclusive seasonal items and bonuses for loyal members.',
    color: '#ef4444',
    delay: 0.6,
  },
  {
    icon: RefreshCw,
    title: 'Regular Updates',
    desc: 'New content, gamemodes, and features released every week.',
    color: '#14b8a6',
    delay: 0.7,
  },
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 cyber-grid opacity-20" />
      <div className="absolute inset-0 hex-pattern opacity-20" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-purple-900/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-purple-500/30 mb-6">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-['Rajdhani'] font-semibold tracking-[0.3em] text-cyan-300 uppercase">Why Choose Us</span>
          </div>

          <h2 className="font-['Orbitron'] font-black text-4xl sm:text-5xl lg:text-6xl text-white mb-4">
            BUILT FOR <span className="shimmer-text">LEGENDS</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto font-['Rajdhani']">
            Everything you need for an elite Minecraft experience, crafted with precision and passion.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((feat) => {
            const Icon = feat.icon;
            return (
              <motion.div
                key={feat.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: feat.delay }}
                whileHover={{ y: -5, scale: 1.02 }}
                className="relative group cursor-default"
              >
                <div
                  className="relative rounded-2xl p-6 border transition-all duration-300 group-hover:border-opacity-60 h-full"
                  style={{
                    background: 'rgba(8, 8, 18, 0.7)',
                    backdropFilter: 'blur(12px)',
                    borderColor: `${feat.color}20`,
                  }}
                >
                  {/* Hover glow */}
                  <div
                    className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-400 pointer-events-none"
                    style={{ background: `radial-gradient(ellipse at 30% 30%, ${feat.color}12, transparent 70%)` }}
                  />

                  {/* Icon */}
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:shadow-lg"
                    style={{
                      background: `linear-gradient(135deg, ${feat.color}30, ${feat.color}10)`,
                      border: `1px solid ${feat.color}40`,
                    }}
                  >
                    <Icon className="w-6 h-6" style={{ color: feat.color }} />
                  </div>

                  <h3 className="font-['Orbitron'] font-bold text-white text-sm mb-2 tracking-wide">{feat.title}</h3>
                  <p className="text-gray-400 text-sm font-['Rajdhani'] leading-relaxed">{feat.desc}</p>

                  {/* Bottom line */}
                  <div
                    className="absolute bottom-0 left-6 right-6 h-[1px] opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{ background: `linear-gradient(90deg, transparent, ${feat.color}60, transparent)` }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
