import { motion } from 'framer-motion';
import { Crown, Trophy, Medal, Star, Flame, Heart } from 'lucide-react';

const donors = [
  {
    rank: 1,
    name: 'xXDragonSlayerXx',
    amount: '$2,450',
    tier: 'TITAN',
    color: '#ef4444',
    glowColor: 'rgba(239, 68, 68, 0.4)',
    avatar: '🐉',
    joinDate: 'Mar 2021',
    donations: 47,
    crownColor: '#FFD700',
  },
  {
    rank: 2,
    name: 'NeonPhoenix',
    amount: '$1,890',
    tier: 'TITAN',
    color: '#f97316',
    glowColor: 'rgba(249, 115, 22, 0.4)',
    avatar: '🔥',
    joinDate: 'Jun 2021',
    donations: 31,
    crownColor: '#C0C0C0',
  },
  {
    rank: 3,
    name: 'CyberVoid',
    amount: '$1,340',
    tier: 'LEGEND',
    color: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    avatar: '⚡',
    joinDate: 'Sep 2021',
    donations: 28,
    crownColor: '#CD7F32',
  },
  {
    rank: 4,
    name: 'ShadowBlade99',
    amount: '$980',
    tier: 'LEGEND',
    color: '#a855f7',
    glowColor: 'rgba(168, 85, 247, 0.3)',
    avatar: '🌙',
    joinDate: 'Jan 2022',
    donations: 19,
    crownColor: null,
  },
  {
    rank: 5,
    name: 'QuantumStrike',
    amount: '$750',
    tier: 'ELITE',
    color: '#06b6d4',
    glowColor: 'rgba(6, 182, 212, 0.3)',
    avatar: '💫',
    joinDate: 'Mar 2022',
    donations: 15,
    crownColor: null,
  },
  {
    rank: 6,
    name: 'VortexKing',
    amount: '$620',
    tier: 'ELITE',
    color: '#8b5cf6',
    glowColor: 'rgba(139, 92, 246, 0.3)',
    avatar: '🌀',
    joinDate: 'May 2022',
    donations: 12,
    crownColor: null,
  },
  {
    rank: 7,
    name: 'PlasmaWitch',
    amount: '$490',
    tier: 'ELITE',
    color: '#ec4899',
    glowColor: 'rgba(236, 72, 153, 0.3)',
    avatar: '✨',
    joinDate: 'Jul 2022',
    donations: 9,
    crownColor: null,
  },
  {
    rank: 8,
    name: 'IronGolem404',
    amount: '$320',
    tier: 'VIP',
    color: '#10b981',
    glowColor: 'rgba(16, 185, 129, 0.3)',
    avatar: '🛡️',
    joinDate: 'Nov 2022',
    donations: 7,
    crownColor: null,
  },
  {
    rank: 9,
    name: 'NightCrawlerX',
    amount: '$210',
    tier: 'VIP',
    color: '#64748b',
    glowColor: 'rgba(100, 116, 139, 0.3)',
    avatar: '🦇',
    joinDate: 'Jan 2023',
    donations: 5,
    crownColor: null,
  },
  {
    rank: 10,
    name: 'StarForge',
    amount: '$150',
    tier: 'VIP',
    color: '#a78bfa',
    glowColor: 'rgba(167, 139, 250, 0.3)',
    avatar: '⭐',
    joinDate: 'Feb 2023',
    donations: 4,
    crownColor: null,
  },
];

const tierConfig: Record<string, { bg: string; text: string; border: string }> = {
  TITAN: { bg: 'rgba(239, 68, 68, 0.1)', text: '#ef4444', border: 'rgba(239, 68, 68, 0.3)' },
  LEGEND: { bg: 'rgba(245, 158, 11, 0.1)', text: '#f59e0b', border: 'rgba(245, 158, 11, 0.3)' },
  ELITE: { bg: 'rgba(6, 182, 212, 0.1)', text: '#06b6d4', border: 'rgba(6, 182, 212, 0.3)' },
  VIP: { bg: 'rgba(168, 85, 247, 0.1)', text: '#a855f7', border: 'rgba(168, 85, 247, 0.3)' },
};

const rankIcons = [
  <Trophy className="w-5 h-5 text-yellow-400" />,
  <Medal className="w-5 h-5 text-gray-300" />,
  <Medal className="w-5 h-5 text-amber-600" />,
];

function TopThreeCard({ donor, index }: { donor: typeof donors[0]; index: number }) {
  const isFirst = index === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.95 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7, delay: index * 0.15 }}
      whileHover={{ y: -6 }}
      className={`relative rounded-2xl overflow-hidden cursor-pointer group ${isFirst ? 'sm:scale-105 sm:z-10' : ''}`}
      style={{
        boxShadow: `0 0 30px ${donor.glowColor}, 0 0 60px ${donor.glowColor.replace('0.4', '0.15')}`,
      }}
    >
      <div
        className="relative p-6 text-center border rounded-2xl"
        style={{
          background: `linear-gradient(160deg, ${donor.glowColor.replace('0.4', '0.12')}, rgba(8,8,20,0.95))`,
          backdropFilter: 'blur(20px)',
          borderColor: `${donor.color}40`,
        }}
      >
        {/* Background glow */}
        <div
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{ background: `radial-gradient(ellipse at 50% 0%, ${donor.color}60, transparent 70%)` }}
        />

        {/* Crown / Medal */}
        <div className="flex justify-center mb-3">
          {donor.crownColor ? (
            <Crown className="w-8 h-8" style={{ color: donor.crownColor, filter: `drop-shadow(0 0 8px ${donor.crownColor})` }} />
          ) : rankIcons[index]}
        </div>

        {/* Avatar */}
        <div className="relative inline-block mb-3">
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center text-4xl mx-auto border-2 transition-all duration-300 group-hover:scale-110"
            style={{
              background: `linear-gradient(135deg, ${donor.color}30, ${donor.color}10)`,
              borderColor: `${donor.color}60`,
              boxShadow: `0 0 20px ${donor.glowColor}`,
            }}
          >
            {donor.avatar}
          </div>
          <div
            className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center font-['Orbitron'] font-black text-xs text-white"
            style={{ background: `linear-gradient(135deg, ${donor.color}, ${donor.color}aa)` }}
          >
            #{donor.rank}
          </div>
        </div>

        {/* Name */}
        <div className="font-['Orbitron'] font-bold text-white text-base mb-1 truncate">{donor.name}</div>

        {/* Tier Badge */}
        <div
          className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-['Orbitron'] font-bold tracking-widest mb-3"
          style={{
            background: tierConfig[donor.tier].bg,
            color: tierConfig[donor.tier].text,
            border: `1px solid ${tierConfig[donor.tier].border}`,
          }}
        >
          <Flame className="w-3 h-3" />
          {donor.tier}
        </div>

        {/* Amount */}
        <div
          className="font-['Orbitron'] font-black text-3xl mb-1"
          style={{ color: donor.color, textShadow: `0 0 20px ${donor.color}80` }}
        >
          {donor.amount}
        </div>
        <div className="text-gray-400 text-xs font-['Rajdhani'] tracking-wider">{donor.donations} donations</div>

        {/* Corner deco */}
        <div className="absolute top-0 left-0 w-5 h-5 border-t-2 border-l-2 rounded-tl-2xl" style={{ borderColor: `${donor.color}60` }} />
        <div className="absolute bottom-0 right-0 w-5 h-5 border-b-2 border-r-2 rounded-br-2xl" style={{ borderColor: `${donor.color}60` }} />
      </div>
    </motion.div>
  );
}

function DonorRow({ donor, index }: { donor: typeof donors[0]; index: number }) {
  const pct = (parseInt(donor.amount.replace(/[$,]/g, '')) / 2450) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, x: -30 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.07 }}
      whileHover={{ x: 4 }}
      className="relative flex items-center gap-4 p-4 rounded-xl cursor-pointer group transition-all duration-300 hover:bg-white/[0.02] border border-transparent hover:border-white/5"
    >
      {/* Rank Number */}
      <div className="flex-shrink-0 w-8 text-center font-['Orbitron'] font-bold text-sm text-gray-500 group-hover:text-gray-300 transition-colors">
        #{donor.rank}
      </div>

      {/* Avatar */}
      <div
        className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center text-xl border transition-all duration-300 group-hover:scale-110"
        style={{
          background: `linear-gradient(135deg, ${donor.color}20, ${donor.color}08)`,
          borderColor: `${donor.color}30`,
        }}
      >
        {donor.avatar}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-['Rajdhani'] font-bold text-white text-sm truncate">{donor.name}</span>
          <span
            className="flex-shrink-0 px-2 py-0.5 rounded-full text-[9px] font-['Orbitron'] font-bold tracking-wider"
            style={{
              background: tierConfig[donor.tier].bg,
              color: tierConfig[donor.tier].text,
              border: `1px solid ${tierConfig[donor.tier].border}`,
            }}
          >
            {donor.tier}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: `${pct}%` }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, delay: 0.3 + index * 0.07, ease: 'easeOut' }}
            className="h-full rounded-full"
            style={{ background: `linear-gradient(90deg, ${donor.color}80, ${donor.color})` }}
          />
        </div>
      </div>

      {/* Amount */}
      <div className="flex-shrink-0 text-right">
        <div className="font-['Orbitron'] font-bold text-sm" style={{ color: donor.color }}>
          {donor.amount}
        </div>
        <div className="text-gray-500 text-[10px] font-['Rajdhani']">{donor.donations} donations</div>
      </div>
    </motion.div>
  );
}

export default function TopDonors() {
  return (
    <section id="donors" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 cyber-grid opacity-20" />
      <div className="absolute top-1/2 left-0 w-[600px] h-[600px] bg-cyan-900/10 rounded-full blur-[120px] pointer-events-none -translate-y-1/2" />
      <div className="absolute top-1/2 right-0 w-[600px] h-[600px] bg-purple-900/10 rounded-full blur-[120px] pointer-events-none -translate-y-1/2" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-cyan-500/30 mb-6">
            <Heart className="w-3.5 h-3.5 text-pink-400" />
            <span className="text-xs font-['Rajdhani'] font-semibold tracking-[0.3em] text-cyan-300 uppercase">Community Heroes</span>
          </div>

          <h2 className="font-['Orbitron'] font-black text-4xl sm:text-5xl lg:text-6xl text-white mb-4">
            TOP <span className="shimmer-text">DONORS</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto font-['Rajdhani']">
            Hall of fame — the legends who keep CyberCraft alive. Thank you for your support.
          </p>
        </motion.div>

        {/* Top 3 Podium */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
          {donors.slice(0, 3).map((donor, i) => (
            <TopThreeCard key={donor.rank} donor={donor} index={i} />
          ))}
        </div>

        {/* Leaderboard List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="glass rounded-2xl border border-purple-500/20 overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center gap-4 px-6 py-4 border-b border-white/5">
            <Trophy className="w-5 h-5 text-yellow-400" />
            <span className="font-['Orbitron'] font-bold text-white tracking-wider">LEADERBOARD</span>
            <div className="ml-auto flex items-center gap-2">
              <Star className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-gray-400 font-['Rajdhani'] tracking-wider">ALL TIME</span>
            </div>
          </div>

          <div className="divide-y divide-white/[0.03] px-2 py-2">
            {donors.slice(3).map((donor, i) => (
              <DonorRow key={donor.rank} donor={donor} index={i} />
            ))}
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-white/5 flex items-center justify-between">
            <span className="text-xs text-gray-500 font-['Rajdhani'] tracking-wider">Showing top 10 donors of all time</span>
            <button className="text-xs text-purple-400 hover:text-purple-300 font-['Rajdhani'] font-semibold tracking-wider transition-colors">
              VIEW ALL →
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
