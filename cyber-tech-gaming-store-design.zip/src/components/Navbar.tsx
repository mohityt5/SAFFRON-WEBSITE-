import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sword, ShoppingCart, Menu, X, Zap, Users, Package, Star, ChevronDown } from 'lucide-react';

const navLinks = [
  { label: 'Store', href: '#store', icon: Package, sub: ['Ranks', 'Keys', 'Cosmetics', 'Boosters'] },
  { label: 'Ranks', href: '#ranks', icon: Star },
  { label: 'Top Donors', href: '#donors', icon: Users },
  { label: 'Features', href: '#features', icon: Zap },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [cartCount] = useState(3);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'glass border-b border-purple-500/20 shadow-lg shadow-purple-900/20'
            : 'bg-transparent'
        }`}
      >
        {/* Top accent line */}
        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-80" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">

            {/* Logo */}
            <motion.a
              href="#"
              className="flex items-center gap-3 group"
              whileHover={{ scale: 1.02 }}
            >
              <div className="relative">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-purple-500/40 group-hover:shadow-purple-500/70 transition-shadow duration-300">
                  <Sword className="w-5 h-5 text-white" />
                </div>
                <div className="absolute -inset-1 bg-gradient-to-br from-purple-600 to-cyan-500 rounded-lg blur opacity-30 group-hover:opacity-60 transition-opacity duration-300 -z-10" />
              </div>
              <div>
                <span className="font-['Orbitron'] font-black text-lg tracking-wider">
                  <span className="text-purple-400">CYBER</span>
                  <span className="text-cyan-400">CRAFT</span>
                </span>
                <div className="text-[9px] text-gray-400 tracking-[0.3em] font-['Rajdhani'] uppercase">Network Store</div>
              </div>
            </motion.a>

            {/* Desktop Nav Links */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <div
                  key={link.label}
                  className="relative"
                  onMouseEnter={() => link.sub && setActiveDropdown(link.label)}
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <a
                    href={link.href}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-semibold text-gray-300 hover:text-white transition-all duration-200 group relative overflow-hidden"
                  >
                    <span className="absolute inset-0 bg-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-md" />
                    <link.icon className="w-3.5 h-3.5 text-purple-400 group-hover:text-cyan-400 transition-colors" />
                    <span className="font-['Rajdhani'] tracking-wider">{link.label}</span>
                    {link.sub && <ChevronDown className="w-3 h-3 opacity-60" />}
                  </a>

                  {/* Dropdown */}
                  <AnimatePresence>
                    {link.sub && activeDropdown === link.label && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.15 }}
                        className="absolute top-full left-0 mt-2 w-44 glass rounded-xl border border-purple-500/20 overflow-hidden shadow-xl shadow-purple-900/30"
                      >
                        {link.sub.map((item) => (
                          <a
                            key={item}
                            href="#store"
                            className="flex items-center gap-2 px-4 py-2.5 text-sm text-gray-300 hover:text-white hover:bg-purple-500/15 transition-all duration-150"
                          >
                            <span className="w-1 h-1 rounded-full bg-cyan-400" />
                            <span className="font-['Rajdhani'] tracking-wide">{item}</span>
                          </a>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-3">
              {/* Online Players Badge */}
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full glass border border-green-500/30">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-sm shadow-green-400" />
                <span className="text-xs text-green-400 font-['Rajdhani'] font-semibold tracking-wider">1,247 ONLINE</span>
              </div>

              {/* Cart */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="relative p-2.5 rounded-xl glass border border-purple-500/30 hover:border-purple-500/60 transition-all duration-200 group"
              >
                <ShoppingCart className="w-5 h-5 text-purple-300 group-hover:text-purple-100 transition-colors" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full text-[10px] font-bold text-white flex items-center justify-center shadow-lg shadow-purple-500/50">
                    {cartCount}
                  </span>
                )}
              </motion.button>

              {/* Login */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="hidden sm:flex neon-btn-purple px-5 py-2 rounded-xl font-['Rajdhani'] font-semibold text-sm tracking-wider transition-all duration-300"
              >
                LOGIN
              </motion.button>

              {/* Mobile Menu Toggle */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="md:hidden p-2 rounded-lg glass border border-purple-500/30"
              >
                {mobileOpen ? <X className="w-5 h-5 text-purple-300" /> : <Menu className="w-5 h-5 text-purple-300" />}
              </button>
            </div>
          </div>
        </div>

        {/* Bottom accent line */}
        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent" />
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="fixed top-16 left-0 right-0 z-40 glass border-b border-purple-500/20 md:hidden overflow-hidden"
          >
            <div className="px-4 py-4 space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-purple-500/10 text-gray-300 hover:text-white transition-all duration-200"
                >
                  <link.icon className="w-4 h-4 text-purple-400" />
                  <span className="font-['Rajdhani'] font-semibold tracking-wider">{link.label}</span>
                </a>
              ))}
              <div className="pt-2">
                <button className="w-full neon-btn-purple px-4 py-2.5 rounded-xl font-['Rajdhani'] font-semibold tracking-wider">
                  LOGIN
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
