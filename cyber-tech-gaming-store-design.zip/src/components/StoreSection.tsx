import { motion } from 'framer-motion';
import { Package, Key, Wand2, Rocket, Tag, Clock, Star } from 'lucide-react';

const categories = [
  { id: 'all', label: 'All Items' },
  { id: 'keys', label: 'Keys & Crates' },
  { id: 'cosmetics', label: 'Cosmetics' },
  { id: 'boosters', label: 'Boosters' },
  { id: 'bundles', label: 'Bundles' },
];

const storeItems = [
  {
    id: 1,
    name: 'Mystery Crate Key',
    category: 'keys',
    price: '$4.99',
    originalPrice: '$7.99',
    icon: Key,
    color: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    badge: 'SALE',
    badgeColor: '#ef4444',
    description: 'Unlock the mystery crate for rare rewards',
    rating: 4.8,
    sold: 12400,
  },
  {
    id: 2,
    name: 'Neon Wing Trails',
    category: 'cosmetics',
    price: '$7.99',
    icon: Wand2,
    color: '#a855f7',
    glowColor: 'rgba(168, 85, 247, 0.4)',
    badge: 'NEW',
    badgeColor: '#06b6d4',
    description: 'Glowing neon wings that trail behind you',
    rating: 4.9,
    sold: 3200,
  },
  {
    id: 3,
    name: '2x XP Booster 7D',
    category: 'boosters',
    price: '$5.99',
    icon: Rocket,
    color: '#06b6d4',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    description: 'Double your XP gains for 7 full days',
    rating: 4.7,
    sold: 8900,
  },
  {
    id: 4,
    name: 'Cosmic Bundle',
    category: 'bundles',
    price: '$19.99',
    originalPrice: '$34.99',
    icon: Package,
    color: '#ec4899',
    glowColor: 'rgba(236, 72, 153, 0.4)',
    badge: '-43%',
    badgeColor: '#ef4444',
    description: '5 keys + wing cosmetic + 14-day booster',
    rating: 5.0,
    sold: 1800,
  },
  {
    id: 5,
    name: 'Dragon Crate Key',
    category: 'keys',
    price: '$9.99',
    icon: Key,
    color: '#ef4444',
    glowColor: 'rgba(239, 68, 68, 0.4)',
    badge: 'HOT',
    badgeColor: '#ef4444',
    description: 'Exclusive dragon crate with legendary loot',
    rating: 4.9,
    sold: 5600,
  },
  {
    id: 6,
    name: 'Hologram Pet',
    category: 'cosmetics',
    price: '$12.99',
    icon: Star,
    color: '#8b5cf6',
    glowColor: 'rgba(139, 92, 246, 0.4)',
    badge: 'RARE',
    badgeColor: '#f59e0b',
    description: 'A glowing holographic companion follows you',
    rating: 4.8,
    sold: 2100,
  },
];

function StoreCard({ item, index }: { item: typeof storeItems[0]; index: number }) {
  const Icon = item.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      whileHover={{ y: -6, scale: 1.02 }}
      className="relative group rounded-2xl cursor-pointer"
      style={{
        boxShadow: `0 4px 20px rgba(0,0,0,0.4)`,
      }}
    >
      <div
        className="relative rounded-2xl overflow-hidden border transition-all duration-300 group-hover:border-opacity-70"
        style={{
          background: 'rgba(8, 8, 18, 0.8)',
          backdropFilter: 'blur(16px)',
          borderColor: `${item.color}30`,
        }}
      >
        {/* Hover glow overlay */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-400 pointer-events-none"
          style={{ background: `radial-gradient(ellipse at 50% 0%, ${item.color}15, transparent 70%)` }}
        />

        {/* Badge */}
        {item.badge && (
          <div
            className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-['Orbitron'] font-black tracking-widest z-10 text-white"
            style={{ background: item.badgeColor, boxShadow: `0 0 10px ${item.badgeColor}60` }}
          >
            {item.badge}
          </div>
        )}

        {/* Icon Area */}
        <div className="relative h-32 flex items-center justify-center overflow-hidden">
          <div
            className="absolute inset-0"
            style={{ background: `radial-gradient(ellipse at 50% 100%, ${item.color}20, transparent 70%)` }}
          />
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center float-icon shadow-2xl"
            style={{
              background: `linear-gradient(135deg, ${item.color}30, ${item.color}10)`,
              border: `1px solid ${item.color}50`,
              boxShadow: `0 0 30px ${item.glowColor}`,
            }}
          >
            <Icon className="w-8 h-8" style={{ color: item.color }} />
          </div>

          {/* Particle dots */}
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full opacity-60"
              style={{
                width: Math.random() * 3 + 1 + 'px',
                height: Math.random() * 3 + 1 + 'px',
                background: item.color,
                top: `${20 + Math.random() * 60}%`,
                left: `${10 + Math.random() * 80}%`,
                animationDelay: `${i * 0.5}s`,
                animation: `particle-float ${3 + i * 0.5}s ease-out infinite`,
              }}
            />
          ))}
        </div>

        {/* Divider */}
        <div className="h-px mx-4" style={{ background: `linear-gradient(90deg, transparent, ${item.color}40, transparent)` }} />

        {/* Content */}
        <div className="p-4">
          <h3 className="font-['Orbitron'] font-bold text-sm text-white mb-1 truncate">{item.name}</h3>
          <p className="text-gray-400 text-xs font-['Rajdhani'] mb-3 leading-relaxed">{item.description}</p>

          {/* Rating & Sales */}
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
              <span className="text-xs text-yellow-400 font-['Rajdhani'] font-semibold">{item.rating}</span>
            </div>
            <span className="text-gray-600 text-xs">|</span>
            <span className="text-gray-400 text-xs font-['Rajdhani']">{item.sold.toLocaleString()} sold</span>
          </div>

          {/* Price & Buy */}
          <div className="flex items-center justify-between">
            <div>
              {item.originalPrice && (
                <div className="text-gray-500 text-xs line-through font-['Rajdhani']">{item.originalPrice}</div>
              )}
              <div
                className="font-['Orbitron'] font-black text-lg"
                style={{ color: item.color }}
              >
                {item.price}
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl font-['Rajdhani'] font-bold text-xs tracking-wider text-white transition-all duration-300"
              style={{
                background: `linear-gradient(135deg, ${item.color}40, ${item.color}20)`,
                border: `1px solid ${item.color}50`,
              }}
            >
              <Tag className="w-3 h-3" />
              BUY
            </motion.button>
          </div>
        </div>

        {/* Corner decorations */}
        <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 rounded-tl-2xl" style={{ borderColor: `${item.color}50` }} />
        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 rounded-br-2xl" style={{ borderColor: `${item.color}50` }} />
      </div>
    </motion.div>
  );
}

export default function StoreSection() {
  return (
    <section id="store" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 cyber-grid opacity-25" />
      <div className="absolute bottom-0 right-1/3 w-[500px] h-[500px] bg-purple-900/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-cyan-500/30 mb-6">
            <Package className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-['Rajdhani'] font-semibold tracking-[0.3em] text-cyan-300 uppercase">Item Shop</span>
          </div>

          <h2 className="font-['Orbitron'] font-black text-4xl sm:text-5xl lg:text-6xl text-white mb-4">
            CYBER <span className="shimmer-text">STORE</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto font-['Rajdhani']">
            Browse our curated collection of exclusive items, cosmetics, keys, and power-ups.
          </p>
        </motion.div>

        {/* Flash Sale Banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative glass rounded-2xl border border-red-500/30 p-5 mb-10 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 via-orange-900/10 to-transparent pointer-events-none" />
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center animate-pulse">
                <Rocket className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <div className="font-['Orbitron'] font-black text-white text-sm tracking-wider">⚡ FLASH SALE — ACTIVE NOW</div>
                <div className="text-gray-400 text-xs font-['Rajdhani'] mt-0.5">Up to 50% off select items. Limited time only!</div>
              </div>
            </div>
            <div className="ml-auto flex items-center gap-2 glass border border-red-500/30 px-4 py-2 rounded-xl">
              <Clock className="w-4 h-4 text-red-400" />
              <span className="font-['Orbitron'] font-bold text-red-400 text-sm tracking-wider">02:47:33</span>
            </div>
          </div>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap gap-2 mb-8"
        >
          {categories.map((cat, i) => (
            <motion.button
              key={cat.id}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className={`px-5 py-2 rounded-xl font-['Rajdhani'] font-semibold text-sm tracking-wider transition-all duration-200 ${
                i === 0
                  ? 'bg-purple-600/40 border border-purple-500/60 text-purple-200'
                  : 'glass border border-white/10 text-gray-400 hover:text-white hover:border-purple-500/30'
              }`}
            >
              {cat.label}
            </motion.button>
          ))}
        </motion.div>

        {/* Items Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {storeItems.map((item, i) => (
            <StoreCard key={item.id} item={item} index={i} />
          ))}
        </div>

        {/* Load More */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-10"
        >
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            className="neon-btn-cyan px-10 py-3.5 rounded-xl font-['Orbitron'] font-bold text-sm tracking-widest transition-all duration-300"
          >
            LOAD MORE ITEMS
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
