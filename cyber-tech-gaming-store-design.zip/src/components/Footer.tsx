import { motion } from 'framer-motion';
import { Sword, MessageCircle, ExternalLink, Mail, Globe, Tv, Terminal } from 'lucide-react';

const footerLinks = {
  Store: ['Ranks', 'Keys & Crates', 'Cosmetics', 'Boosters', 'Gift Cards'],
  Support: ['Help Center', 'Contact Us', 'Bug Reports', 'Refund Policy', 'Discord Server'],
  Network: ['Server IP', 'Status Page', 'Map Viewer', 'Leaderboards', 'Season Info'],
  Legal: ['Terms of Service', 'Privacy Policy', 'EULA', 'Cookie Policy'],
};

const socials = [
  { icon: Globe, label: 'Twitter', href: '#', color: '#1da1f2' },
  { icon: Tv, label: 'YouTube', href: '#', color: '#ff0000' },
  { icon: MessageCircle, label: 'Discord', href: '#', color: '#5865f2' },
  { icon: Terminal, label: 'GitHub', href: '#', color: '#ffffff' },
  { icon: Mail, label: 'Email', href: '#', color: '#a855f7' },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-purple-500/10">
      {/* Background */}
      <div className="absolute inset-0 cyber-grid opacity-15" />
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-purple-900/8 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Newsletter CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative glass rounded-2xl border border-purple-500/20 p-8 my-16 overflow-hidden text-center"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 via-transparent to-cyan-900/20 pointer-events-none" />
          <div className="relative">
            <h3 className="font-['Orbitron'] font-black text-2xl sm:text-3xl text-white mb-3">
              JOIN THE <span className="shimmer-text">REVOLUTION</span>
            </h3>
            <p className="text-gray-400 font-['Rajdhani'] mb-6 max-w-lg mx-auto">
              Subscribe for exclusive deals, early access to new features, and server announcements.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 px-4 py-3 rounded-xl glass border border-purple-500/30 text-white placeholder-gray-500 font-['Rajdhani'] text-sm focus:outline-none focus:border-purple-500/60 focus:ring-1 focus:ring-purple-500/30"
              />
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="px-6 py-3 rounded-xl font-['Orbitron'] font-bold text-sm tracking-wider text-white"
                style={{ background: 'linear-gradient(135deg, #a855f7, #8b5cf6)' }}
              >
                SUBSCRIBE
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Main Footer */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-8 pb-12">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
                <Sword className="w-5 h-5 text-white" />
              </div>
              <span className="font-['Orbitron'] font-black text-lg">
                <span className="text-purple-400">CYBER</span>
                <span className="text-cyan-400">CRAFT</span>
              </span>
            </div>
            <p className="text-gray-500 text-sm font-['Rajdhani'] leading-relaxed mb-5">
              The most advanced Minecraft network. Season 7 now live.
            </p>

            {/* Socials */}
            <div className="flex gap-2 flex-wrap">
              {socials.map((s) => {
                const Icon = s.icon;
                return (
                  <motion.a
                    key={s.label}
                    href={s.href}
                    whileHover={{ scale: 1.1, y: -2 }}
                    className="w-9 h-9 rounded-lg glass border border-white/10 flex items-center justify-center transition-all duration-200 hover:border-white/20"
                    title={s.label}
                  >
                    <Icon className="w-4 h-4 text-gray-400 hover:text-white transition-colors" />
                  </motion.a>
                );
              })}
            </div>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([cat, links]) => (
            <div key={cat}>
              <h4 className="font-['Orbitron'] font-bold text-white text-xs tracking-widest mb-4">{cat.toUpperCase()}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-gray-500 hover:text-purple-300 text-sm font-['Rajdhani'] transition-colors duration-200 flex items-center gap-1 group"
                    >
                      <span>{link}</span>
                      <ExternalLink className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/5 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-gray-600 text-xs font-['Rajdhani'] tracking-wider">
            © 2024 CyberCraft Network. All rights reserved. Not affiliated with Mojang or Microsoft.
          </div>
          <div className="flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs text-green-400 font-['Rajdhani'] font-semibold tracking-wider">ALL SYSTEMS OPERATIONAL</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
