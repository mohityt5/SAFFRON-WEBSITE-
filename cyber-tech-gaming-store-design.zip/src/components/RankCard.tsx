import { motion } from 'framer-motion';
import { Check, Zap, Star, Crown, Shield, Flame } from 'lucide-react';

interface Rank {
  id: string;
  name: string;
  price: string;
  originalPrice?: string;
  tier: 'vip' | 'elite' | 'legend' | 'titan';
  color: string;
  glowColor: string;
  borderColor: string;
  bgGradient: string;
  iconBg: string;
  image: string;
  badge?: string;
  features: string[];
  icon: React.ComponentType<{ className?: string }>;
  popular?: boolean;
  limited?: boolean;
}

const ranks: Rank[] = [
  {
    id: 'vip',
    name: 'VIP',
    price: '$9.99',
    tier: 'vip',
    color: '#a855f7',
    glowColor: 'rgba(168, 85, 247, 0.5)',
    borderColor: 'border-purple-500/50',
    bgGradient: 'from-purple-900/30 via-purple-950/20 to-transparent',
    iconBg: 'from-purple-600 to-violet-700',
    image: '/images/rank-vip.png',
    icon: Star,
    features: [
      'Reserved queue slot',
      'Custom chat prefix [VIP]',
      '2x XP Multiplier',
      'Exclusive VIP kit',
      'Access to /fly in lobby',
      '5 home locations',
      'Custom particle effects',
    ],
  },
  {
    id: 'elite',
    name: 'ELITE',
    price: '$24.99',
    originalPrice: '$34.99',
    tier: 'elite',
    color: '#06b6d4',
    glowColor: 'rgba(6, 182, 212, 0.5)',
    borderColor: 'border-cyan-500/50',
    bgGradient: 'from-cyan-900/30 via-cyan-950/20 to-transparent',
    iconBg: 'from-cyan-500 to-teal-600',
    image: '/images/rank-elite.png',
    badge: 'BEST VALUE',
    icon: Crown,
    popular: true,
    features: [
      'All VIP perks included',
      'Custom chat prefix [ELITE]',
      '3x XP Multiplier',
      'Exclusive ELITE kit (daily)',
      'Full /fly access',
      '15 home locations',
      'Exclusive cosmetic set',
      'Priority support',
    ],
  },
  {
    id: 'legend',
    name: 'LEGEND',
    price: '$49.99',
    tier: 'legend',
    color: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.5)',
    borderColor: 'border-amber-500/50',
    bgGradient: 'from-amber-900/30 via-amber-950/20 to-transparent',
    iconBg: 'from-yellow-500 to-amber-600',
    image: '/images/rank-legend.png',
    icon: Zap,
    features: [
      'All ELITE perks included',
      'Custom chat prefix [LEGEND]',
      '5x XP Multiplier',
      'Exclusive LEGEND kit',
      'Unique title effects',
      '30 home locations',
      'Custom join/leave messages',
      'Exclusive mount collection',
      '10% store discount',
    ],
  },
  {
    id: 'titan',
    name: 'TITAN',
    price: '$99.99',
    tier: 'titan',
    color: '#ef4444',
    glowColor: 'rgba(239, 68, 68, 0.5)',
    borderColor: 'border-red-500/50',
    bgGradient: 'from-red-900/30 via-red-950/20 to-transparent',
    iconBg: 'from-red-600 to-rose-700',
    image: '/images/rank-titan.png',
    badge: 'EXCLUSIVE',
    icon: Flame,
    limited: true,
    features: [
      'All LEGEND perks included',
      'Custom chat prefix [TITAN]',
      '10x XP Multiplier',
      'God-tier TITAN kit',
      'Custom neon trail effects',
      'Unlimited homes',
      'Custom server commands',
      'Exclusive TITAN armor set',
      '25% store discount',
      'Monthly mystery crate',
    ],
  },
];

const tierCardClass: Record<string, string> = {
  vip: 'rank-card-vip',
  elite: 'rank-card-elite',
  legend: 'rank-card-legend',
  titan: 'rank-card-titan',
};

function RankCard({ rank, index }: { rank: Rank; index: number }) {
  const RankIcon = rank.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay: index * 0.12, ease: 'easeOut' }}
      whileHover={{ y: -8, scale: 1.02 }}
      className={`relative group rounded-2xl ${tierCardClass[rank.tier]} cursor-pointer`}
    >
      {/* Card glass background */}
      <div className={`relative rounded-2xl overflow-hidden border ${rank.borderColor} bg-gradient-to-b ${rank.bgGradient} backdrop-blur-xl`}
        style={{ background: 'rgba(8, 8, 18, 0.75)', backdropFilter: 'blur(20px)' }}
      >
        {/* Scan line overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none rounded-2xl" />

        {/* Popular/Exclusive Badge */}
        {(rank.badge || rank.popular) && (
          <div
            className="absolute top-4 right-4 px-3 py-1 rounded-full text-[10px] font-['Orbitron'] font-bold tracking-widest z-20"
            style={{
              background: `linear-gradient(135deg, ${rank.color}40, ${rank.color}20)`,
              border: `1px solid ${rank.color}60`,
              color: rank.color,
              boxShadow: `0 0 10px ${rank.color}40`,
            }}
          >
            {rank.badge || 'POPULAR'}
          </div>
        )}

        {/* Limited Tag */}
        {rank.limited && (
          <div className="absolute top-4 left-4 flex items-center gap-1 px-2 py-1 bg-red-500/20 border border-red-500/40 rounded-full z-20">
            <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
            <span className="text-[9px] text-red-400 font-['Rajdhani'] font-bold tracking-widest">LIMITED</span>
          </div>
        )}

        {/* Header */}
        <div className="relative p-6 pb-4">
          {/* Background gradient glow */}
          <div
            className="absolute inset-0 opacity-20 pointer-events-none"
            style={{ background: `radial-gradient(ellipse at 50% 0%, ${rank.color}60, transparent 70%)` }}
          />

          {/* Icon + Image */}
          <div className="flex justify-center mb-4">
            <div className="relative">
              {/* Rotating rings */}
              <div
                className="absolute inset-0 m-auto rounded-full border opacity-30 group-hover:opacity-70 transition-opacity"
                style={{
                  width: '100px',
                  height: '100px',
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                  borderColor: rank.color,
                  borderTopColor: 'transparent',
                  animation: 'ring-rotate 3s linear infinite',
                }}
              />
              <div
                className="absolute inset-0 m-auto rounded-full border opacity-20 group-hover:opacity-50 transition-opacity"
                style={{
                  width: '120px',
                  height: '120px',
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                  borderColor: rank.color,
                  borderBottomColor: 'transparent',
                  animation: 'ring-rotate-reverse 4s linear infinite',
                }}
              />

              {/* Image */}
              <div className="relative w-20 h-20 flex-icon">
                <img
                  src={rank.image}
                  alt={rank.name}
                  className="w-20 h-20 object-contain float-icon drop-shadow-2xl"
                  style={{ filter: `drop-shadow(0 0 16px ${rank.color})` }}
                />
              </div>
            </div>
          </div>

          {/* Rank Name */}
          <div className="text-center mb-1">
            <div className="font-['Orbitron'] font-black text-2xl tracking-widest" style={{ color: rank.color, textShadow: `0 0 20px ${rank.color}80` }}>
              {rank.name}
            </div>
            <div className="flex justify-center gap-1 mt-1">
              {[...Array(rank.id === 'vip' ? 1 : rank.id === 'elite' ? 2 : rank.id === 'legend' ? 3 : 4)].map((_, i) => (
                <span key={i} style={{ color: rank.color }}>
                  <RankIcon className="w-3 h-3" />
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px mx-6" style={{ background: `linear-gradient(90deg, transparent, ${rank.color}50, transparent)` }} />

        {/* Price */}
        <div className="px-6 py-4 text-center">
          {rank.originalPrice && (
            <div className="text-gray-500 text-sm line-through mb-1 font-['Rajdhani']">{rank.originalPrice}</div>
          )}
          <div className="font-['Orbitron'] font-black text-4xl text-white">
            {rank.price}
          </div>
          <div className="text-gray-400 text-xs font-['Rajdhani'] tracking-widest mt-1">ONE-TIME PAYMENT</div>
        </div>

        {/* Divider */}
        <div className="h-px mx-6 mb-4" style={{ background: `linear-gradient(90deg, transparent, ${rank.color}30, transparent)` }} />

        {/* Features */}
        <div className="px-6 pb-6 space-y-2.5">
          {rank.features.map((feature) => (
            <div key={feature} className="flex items-start gap-3">
              <div className="mt-0.5 flex-shrink-0 w-4 h-4 rounded-full flex items-center justify-center"
                style={{ background: `${rank.color}20`, border: `1px solid ${rank.color}50` }}>
                <Check className="w-2.5 h-2.5" style={{ color: rank.color }} />
              </div>
              <span className="text-gray-300 text-sm font-['Rajdhani'] leading-tight">{feature}</span>
            </div>
          ))}
        </div>

        {/* Buy Button */}
        <div className="px-6 pb-6">
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="w-full py-3.5 rounded-xl font-['Orbitron'] font-bold text-sm tracking-widest text-white relative overflow-hidden group/btn"
            style={{
              background: `linear-gradient(135deg, ${rank.color}30, ${rank.color}15)`,
              border: `1px solid ${rank.color}60`,
            }}
          >
            <div
              className="absolute inset-0 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300"
              style={{ background: `linear-gradient(135deg, ${rank.color}50, ${rank.color}30)` }}
            />
            <span className="relative" style={{ color: rank.color }}>
              PURCHASE NOW
            </span>
          </motion.button>
        </div>

        {/* Corner decorations */}
        <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 rounded-tl-2xl" style={{ borderColor: `${rank.color}60` }} />
        <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 rounded-br-2xl" style={{ borderColor: `${rank.color}60` }} />
      </div>
    </motion.div>
  );
}

export default function RankSection() {
  return (
    <section id="ranks" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 cyber-grid opacity-30" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-purple-900/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-purple-500/30 mb-6">
            <Shield className="w-3.5 h-3.5 text-purple-400" />
            <span className="text-xs font-['Rajdhani'] font-semibold tracking-[0.3em] text-purple-300 uppercase">Rank Store</span>
          </div>

          <h2 className="font-['Orbitron'] font-black text-4xl sm:text-5xl lg:text-6xl text-white mb-4">
            CHOOSE YOUR{' '}
            <span className="shimmer-text">RANK</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto font-['Rajdhani']">
            Unlock exclusive perks, dominate the leaderboards, and showcase your status across all CyberCraft servers.
          </p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
          {ranks.map((rank, i) => (
            <RankCard key={rank.id} rank={rank} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
